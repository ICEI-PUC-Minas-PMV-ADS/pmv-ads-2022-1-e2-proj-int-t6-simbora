﻿namespace WebBackEnd_Simbora.Models
{
    public class boolean
    {
    }
}