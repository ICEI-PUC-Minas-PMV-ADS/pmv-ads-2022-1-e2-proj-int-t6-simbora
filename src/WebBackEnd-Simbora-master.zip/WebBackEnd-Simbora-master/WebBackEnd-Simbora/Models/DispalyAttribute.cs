﻿using System;

namespace WebBackEnd_Simbora.Models
{
    internal class DispalyAttribute : Attribute
    {
        public string Name { get; set; }
    }
}